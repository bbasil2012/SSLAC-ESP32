mkdir backup
tools\curl -F "data=@backup\channels.json" http://$1/upload
tools\curl -F "data=@backup\groups.json" http://$1/upload
tools\curl -F "data=@backup\dosing.json" http://$1/upload
tools\curl -F "data=@backup\config.json" http://$1/upload
tools\curl -F "data=@backup\fans.json" http://$1/upload
tools\curl -F "data=@backup\ds18b20.json" http://$1/upload
tools\curl -F "data=@backup\timers.json" http://$1/upload
tools\curl -F "data=@backup\SSLAC32.html.gz" http://$1/upload


