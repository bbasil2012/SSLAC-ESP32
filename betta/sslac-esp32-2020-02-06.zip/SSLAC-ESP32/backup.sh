mkdir backup
curl http://$1/groups.json -o backup/groups.json
curl http://$1/channels.json -o backup/channels.json
curl http://$1/dosing.json -o backup/dosing.json
curl http://$1/config.json -o backup/config.json
curl http://$1/fans.json -o backup/fans.json
curl http://$1/ds18b20.json -o backup/ds18b20.json
curl http://$1/timers.json -o backup/timers.json
curl http://$1/SSLAC32.html.gz -o backup/SSLAC32.html.gz


