tools/esptool --chip esp32 --port $1 --baud 115200 erase_flash
